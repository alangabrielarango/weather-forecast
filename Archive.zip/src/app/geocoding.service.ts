import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Coordinate } from './common';

@Injectable({
  providedIn: 'root'
})
export class GeocodingService {
  private apiKey = 'AIzaSyDxEy2RXXn77vh8g6vXS8xrpJJSjuPrEjA';
  private latitude = 0;
  private longitude = 0;

  constructor(private http: HttpClient) {}

  getCoordinates(city: string): Observable<any> {
    const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(city)}&key=${this.apiKey}`;
    return this.http.get(url);
  }

  getCurrentPosition(): Coordinate {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        position => {
            this.latitude = parseFloat(position.coords.latitude.toFixed(2));
            this.longitude = parseFloat(position.coords.longitude.toFixed(2));
        },
        error => {
          console.error('Error getting geolocation:', error);
        }
      );
    } else {
      console.error('Geolocation is not supported by this browser.');
    }
    return { latitude: this.latitude, longitude: this.longitude };
  }
}
